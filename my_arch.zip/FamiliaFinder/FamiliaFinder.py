import requests, time, os, sys, re, socket
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from multiprocessing.pool import ThreadPool
from colorama import Fore, Back, Style
from datetime import datetime

banner = """
\t ______              _ _ _      ______ _           _           
\t |  ___|            (_) (_)     |  ___(_)         | |          
\t | |_ __ _ _ __ ___  _| |_  __ _| |_   _ _ __   __| | ___ _ __ 
\t |  _/ _` | '_ ` _ \| | | |/ _` |  _| | | '_ \ / _` |/ _ \ '__|
\t | || (_| | | | | | | | | | (_| | |   | | | | | (_| |  __/ |   
\t \_| \__,_|_| |_| |_|_|_|_|\__,_\_|   |_|_| |_|\__,_|\___|_|   
\t                                              V 1.0.7
\t                                              Familia V2
"""
print(Fore.MAGENTA + banner)

Subdomains = []
Done = 0
Sets = 0

def VirusTotal(domain_name):
    global SavingSwitch, LimiterSwitch, SelectedDomain, AfterT, AfterL, AfterS, Done, Subdomains, sets
    URL_ = "https://www.virustotal.com/api/v3/domains/"+domain_name+"/subdomains?limit=40"
    while 1:
        headers = {"Content-Type": "application/json", "X-Apikey": "8d08e7f490646654551560f5496870178dab5f129f0879f440672a760f9d6147"}
        r = requests.get(URL_, headers=headers).content
        ALL_R_COUNTS = r.count('"id"')
        MY_COUNTER = 1
        for xd in xrange(ALL_R_COUNTS):
            ID = r.split('"id": "')[MY_COUNTER].split('"')[0]
            try:
                req = requests.get("https://" + ID, timeout=5, verify=False)
                IP = socket.gethostbyname(ID)
                if req.status_code == 200:
                    print(Fore.GREEN + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + ID + Fore.YELLOW + " ->> ({})".format(IP))
                elif req.status_code == 301 or req.status_code == 302:
                    print(Fore.WHITE + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + ID + Fore.YELLOW + " ->> ({})".format(IP))
                elif req.status_code == 400 or req.status_code == 401:
                    print(Fore.CYAN + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + ID + Fore.YELLOW + " ->> ({})".format(IP))
                elif req.status_code == 403 or req.status_code == 404:
                    print(Fore.RED + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + ID + Fore.YELLOW + " ->> ({})".format(IP))
                elif req.status_code == 405 or req.status_code == 406:
                    print(Fore.BLUE + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + ID + Fore.YELLOW + " ->> ({})".format(IP))
                else:
                    print(Fore.MAGENTA + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + ID + Fore.YELLOW + " ->> ({})".format(IP))
                if SavingSwitch == "ON":
                    file = open(AfterS+".txt", "a+")
                    file.write(str(req.status_code) + ": " + ID + " ->> " + IP + "\n")
                    file.close()
                Subdomains.append(ID)
                Sets+=1
            except Exception as e:
                #print str(e) + "    " + ID
                print(Fore.RED + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + "FAIL" + " ({}) : ".format(str(Sets)) + ID)
                Subdomains.append(ID)
                Sets+=1
                if SavingSwitch == "ON":
                    file = open(AfterS+".txt", "a+")
                    file.write("FAIL: " + ID + "\n")
                    file.close()
                pass
            MY_COUNTER+=1
        if '"next"' in r:
            URL_ = r.split('"next": "')[1].split('"')[0]
        else:
            break

def CheckDomainSubsMap(sub):
    global SavingSwitch, LimiterSwitch, SelectedDomain, AfterT, AfterL, AfterS, Done, Subdomains, sets
    try:
        req = requests.get("https://" + sub + "." + SelectedDomain, timeout=5, verify=False)
        IP = socket.gethostbyname(sub + "." + SelectedDomain)
        if req.status_code == 200:
            print(Fore.GREEN + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Done)) + sub + "." + SelectedDomain + Fore.YELLOW + " ->> ({})".format(IP))
        elif req.status_code == 301 or req.status_code == 302:
            print(Fore.WHITE + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Done)) + sub + "." + SelectedDomain + Fore.YELLOW + " ->> ({})".format(IP))
        elif req.status_code == 400 or req.status_code == 401:
            print(Fore.CYAN + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Done)) + sub + "." + SelectedDomain + Fore.YELLOW + " ->> ({})".format(IP))
        elif req.status_code == 403 or req.status_code == 404:
            print(Fore.RED + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Done)) + sub + "." + SelectedDomain + Fore.YELLOW + " ->> ({})".format(IP))
        elif req.status_code == 405 or req.status_code == 406:
            print(Fore.BLUE + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Done)) + sub + "." + SelectedDomain + Fore.YELLOW + " ->> ({})".format(IP))
        else:
            print(Fore.MAGENTA + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Done)) + sub + "." + SelectedDomain + Fore.YELLOW + " ->> ({})".format(IP))
        if SavingSwitch == "ON":
            if sub+"."+SelectedDomain in Subdomains:
                pass
            else:
                Subdomains.append(sub+"."+SelectedDomain)
                file = open(AfterS+".txt", "a+")
                file.write(str(req.status_code) + ": " + sub+"."+SelectedDomain + " ->> " + IP + "\n")
                file.close()
        Done+1
    except:
        #print "BAD: " + "https://" + sub + "." + SelectedDomain
        #print(Fore.RED + "\tBAD ({}) : ".format(str(Done)) + Fore.WHITE + sub + "." + SelectedDomain)
        pass
        Done+=1

def CheckDomainCRTSH(domain):
    global SavingSwitch, LimiterSwitch, SelectedDomain, AfterT, AfterL, AfterS, Done, Subdomains, Sets
    src = requests.get("https://crt.sh/?q=%25.{}".format(domain), verify=False).content
    #src = open("content.txt", "r").read()
    PayloadImports = re.findall("[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.{}".format(domain), src)
    for i in PayloadImports:
        i = i.replace("<TD>", ""); i = i.replace("<TD>", ""); i = i.replace("<TD", ""); i = i.replace("<T", ""); i = i.replace("Ecrt.sh|%.", "")
        i = i.replace("TD>", ""); i = i.replace("Ecrt.sh | %", ""); i = i.replace('href="atom?q=', ""); i = i.replace("Ecrt.sh|%.", "")
        i = i.replace("<BR>", ""); i = i.replace(" A ", ""); i = i.replace("<BR", ""); i = i.replace('font-size:8pt" href="?q=', "")
        i = i.replace("BR>", ""); i = i.replace("  ", ""); i = i.replace("R>", ""); i = i.replace("&nbsp;&nbsp;Search: '", ""); i = i.replace("Ecrt.sh|%", "")
        i = i.replace("D>", ""); i = i.replace(' A href="?q=', ""); i = i.replace(">", ""); i = i.replace('nbsp;A href="?q=', "")
        i = i.replace("<", ""); i = i.replace('A href="?q=', ""); i = i.replace("   ", ""); i = i.replace("  ", ""); i = i.replace(" ", "")
        if i in Subdomains:
            pass
        else:
            if "@" in i:
                pass
            else:
                try:
                    req = requests.get("https://" + i, timeout=5, verify=False)
                    IP = socket.gethostbyname(i)
                    if req.status_code == 200:
                        print(Fore.GREEN + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + i + Fore.YELLOW + " ->> ({})".format(IP))
                    elif req.status_code == 301 or req.status_code == 302:
                        print(Fore.WHITE + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + i + Fore.YELLOW + " ->> ({})".format(IP))
                    elif req.status_code == 400 or req.status_code == 401:
                        print(Fore.CYAN + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + i + Fore.YELLOW + " ->> ({})".format(IP))
                    elif req.status_code == 403 or req.status_code == 404:
                        print(Fore.RED + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + i + Fore.YELLOW + " ->> ({})".format(IP))
                    elif req.status_code == 405 or req.status_code == 406:
                        print(Fore.BLUE + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + i + Fore.YELLOW + " ->> ({})".format(IP))
                    else:
                        print(Fore.MAGENTA + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + str(req.status_code) + " ({}) : ".format(str(Sets)) + i + Fore.YELLOW + " ->> ({})".format(IP))
                    if SavingSwitch == "ON":
                        file = open(AfterS+".txt", "a+")
                        file.write(str(req.status_code) + ": " + i + " ->> " + IP + "\n")
                        file.close()
                    Subdomains.append(i)
                    Sets+=1
                except Exception as e:
                    #print str(e) + "    " + i
                    print(Fore.RED + "\t[{}] ".format(datetime.now().strftime("%H:%M:%S")) + "FAIL" + " ({}) : ".format(str(Sets)) + i)
                    Subdomains.append(i)
                    Sets+=1
                    if SavingSwitch == "ON":
                        file = open(AfterS+".txt", "a+")
                        file.write("FAIL: " + i + "\n")
                        file.close()
                    pass

subdomains = requests.get("https://raw.githubusercontent.com/SirBugs/FamiliaFinder/main/subs.doms.xmap.txt", verify=False).content.split("\n")
Args = len(sys.argv)

options = ['-h', '-s', '-l', '-t']
inst = """
\t -s
\t    This switch would be followed by the .txt file name you wanna save in
\t -l
\t    This switch is selecting limit of the subs have to be checked
\t -h
\t    This switch is only submitted one
\t -t
\t    This switch is cotrolling the threads number (Suggested=50)
\t *
\t    All switches are written in SMALL letters normally
\t *
\t    This tool list is getting updated day by day, adding more stuff, options, subs, etc..
\t *
\t    For more info aboue HTTP STATUS CODES, Visit: https://github.com/SirBugs/FamiliaSubFinder/StatusCodes.txt
"""

SavingSwitch = "OFF"
LimiterSwitch = "OFF"
SuggestedThreads = 50

BashLine = ""
for arg in sys.argv:
    if ".py" in arg: pass
    else: BashLine = BashLine + arg + " "

if Args == 1 or "-h" in BashLine:
    print inst
    quit()
if Args == 2 and "-h" not in BashLine:
    pass
if Args >= 2:
    SelectedTool = sys.argv[1]
    SelectedDomain = sys.argv[2]
    if "-s" in BashLine:
        AfterS = BashLine.split("-s ")[1]
        try:
            AfterS = AfterS.split(" ")
            AfterS = AfterS[0]
        except:
                pass
        SavingSwitch = "ON"
    if "-l" in BashLine:
        AfterL = BashLine.split("-l ")[1]
        try:
            AfterL = AfterL.split(" ")
            AfterL = AfterL[0]
        except:
            pass
        LimiterSwitch = "ON"
    if "-t" in BashLine:
        AfterT = BashLine.split("-t ")[1]
        try:
            AfterT = AfterT.split(" ")
            AfterT = AfterT[0]
        except:
            pass
        SuggestedThreads = int(AfterT)
    CheckDomainSubsMap(SelectedDomain)
    # // Checking Function
    if SelectedTool == "SUB":
        try:
            if __name__ == '__main__':
                pool = ThreadPool(SuggestedThreads)
                print(Fore.YELLOW + "\tCurrent InUse Tool: " + Fore.CYAN + SelectedTool + "\n")
                print(Fore.YELLOW + "\tSubdomains List Current Size: " + Fore.CYAN + str(len(subdomains)) + "\n")
                print(Fore.YELLOW + "\tMethod: "  + Fore.CYAN + "GET" + "\n")
                print(Fore.YELLOW + "\tThreads: " + Fore.CYAN + str(SuggestedThreads) + "\n")
                print(Fore.YELLOW + "\tTarget: "  + Fore.CYAN + SelectedDomain + "\n")
                print(Fore.MAGENTA + "\t[{}] STARTING BRUTE!\n".format(datetime.now().strftime("%H:%M:%S")))
                ree = requests.get("https://raw.githubusercontent.com/SirBugs/FamiliaFinder/main/subs.doms.xmap.txt", verify=False).content.split("\n")
                for _ in pool.imap_unordered(CheckDomainSubsMap, ree):
                    if LimiterSwitch == "ON" and Done == int(AfterL):
                        #print str(Done) + " Limiter: " + LimiterSwitch
                        print(Fore.GREEN + str(Done) + " Limiter: " + LimiterSwitch)
                        quit()
                    pass
                print(Fore.MAGENTA + "\n\t[{}] STARTING CRT.SH Search!\n".format(datetime.now().strftime("%H:%M:%S")))
                CheckDomainCRTSH(SelectedDomain)
                print(Fore.MAGENTA + "\n\t[{}] STARTING VIRUSTOTAL Search!\n".format(datetime.now().strftime("%H:%M:%S")))
                VirusTotal(SelectedDomain)
        except:
            pass
    elif SelectedTool == "DIR":
        print "Dir Tools Starting!"
    else:
        print "Not A Tool To Use!"
