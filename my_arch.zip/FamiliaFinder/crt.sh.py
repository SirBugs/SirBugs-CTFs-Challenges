import requests, re
from colorama import Fore, Back, Style
from datetime import datetime

print "S"
#src = requests.get("https://crt.sh/?q=%25.yahoo.com").content
src = open("/Users/sirbugs/Desktop/content2.txt", "r").read()
print "Step1"
PayloadImports = re.findall("[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.[a-z0-9]*.grab.com", src)
print "Step2"
Subdomains = []

#print PayloadImports
for i in PayloadImports:
    i = i.replace("<TD>", ""); i = i.replace("<TD>", "")
    i = i.replace("<TD", ""); i = i.replace("<T", "")
    i = i.replace("TD>", ""); i = i.replace("Ecrt.sh | %", "")
    i = i.replace('href="atom?q=', ""); i = i.replace("Ecrt.sh|%.", "")
    i = i.replace("<BR>", ""); i = i.replace(" A ", "")
    i = i.replace("<BR", ""); i = i.replace('font-size:8pt" href="?q=', "")
    i = i.replace("BR>", ""); i = i.replace("  ", "");
    i = i.replace("R>", ""); i = i.replace("&nbsp;&nbsp;Search: '", "")
    i = i.replace("D>", ""); i = i.replace(' A href="?q=', "")
    i = i.replace(">", ""); i = i.replace('nbsp;A href="?q=', "")
    i = i.replace("<", ""); i = i.replace('A href="?q=', "")
    i = i.replace("   ", ""); i = i.replace("  ", ""); i = i.replace(" ", "")
    if i in Subdomains:
        pass
    else:
        if "@" in i:
            pass
        else:
            print(Fore.GREEN + "\t" + i)
            Subdomains.append(i)
            #print i
